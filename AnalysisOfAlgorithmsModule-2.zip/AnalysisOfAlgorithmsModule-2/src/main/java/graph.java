import java.util.List;
import java.util.Map;

public class graph {

    private  Map<vertex, List<vertex>> adjacentVertices;

    public graph(Map<vertex, List<vertex>> adjacentVertices) {
        this.adjacentVertices = adjacentVertices;
    }


    public Map<vertex, List<vertex>> getAdjacentVertices() {
        return adjacentVertices;
    }

    public void setAdjacentVertices(Map<vertex, List<vertex>> adjacentVertices) {
        this.adjacentVertices = adjacentVertices;
    }
    
}
