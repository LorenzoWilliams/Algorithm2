import java.util.*;
import java.util.ArrayList;
import java.util.Random;

public class graph4 {

    private  Map<String, List<vertex>> adjacentVertices;

    public graph4(Map<String, List<vertex>> adjacentVertices) {
        this.adjacentVertices = adjacentVertices;
    }

    public graph4() {
        this.adjacentVertices = new HashMap<>();
    }

    public Map<String, List<vertex>> getAdjacentVertices() {
        return adjacentVertices;
    }

    public void setAdjacentVertices(Map<String, List<vertex>> adjacentVertices) {
        this.adjacentVertices = adjacentVertices;
    }

    void addVertex(String node){
        adjacentVertices.putIfAbsent(node,new ArrayList<>());
    }
    
   public void  removeVertex(String node){
        vertex v = new vertex(node);

        adjacentVertices.values().stream().forEach(e -> e.remove(v));
    }

    void addEdge(String node1,String node2,int distane){

        vertex vertex1 = new vertex(node1);
        vertex1.setDistance(distane);
        vertex vertex2 = new vertex(node2);
        vertex2.setDistance(distane);

        adjacentVertices.get(node1).add(vertex2);
        adjacentVertices.get(node2).add(vertex1);

    }
    void addEdge(String node1,String node2,int distance, int heuristic){

        vertex vertex1 = new vertex(node1);
        vertex1.setDistance(distance);
        vertex vertex2 = new vertex(node2);
        vertex2.setDistance(distance);
        vertex2.setHeuristic(heuristic);

        adjacentVertices.get(node1).add(vertex2);
        adjacentVertices.get(node2).add(vertex1);

    }

    List<String> closedList = new ArrayList<>();
    public List<String> findRoute(String start, String target) {

        if (closedList.contains(start)){
            System.out.println("already been here");
        }else{
            closedList.add(start);
            System.out.println(start + " Has Been Added");

            List<vertex> currentNode = adjacentVertices.get(start);

            vertex smallest = (vertex) currentNode.toArray()[0];

            System.out.println( smallest.getnode() + " smallest");

            for (int i = 0; i < currentNode.size(); i++) {
                    vertex check = (vertex) currentNode.toArray()[i];
                    System.out.println();
                    if (check.getDistance() < smallest.getDistance()) {
                        System.out.println("Swapping  "+check.getnode() +" For " + smallest.getnode());
                        if (closedList.contains(check)){

                        }else{
                            smallest = check;
                        }
                    }
                }
                if (!(closedList.contains(smallest.getnode()))) {
                    {
                        System.out.println( "before recursive loop :" + smallest.getnode());
                        findRoute(smallest.getnode(),target);
                    }

                }
        }
            return closedList;
        }


    List<String> traveledList = new ArrayList<>();

    public void alreadyVisted(String nodeName){
        for (Map.Entry<String, List<vertex>> e: getAdjacentVertices().entrySet()) {
//            System.out.println("KEY : " + e.getKey() + "  Value : ");
            List<vertex> nextNode = e.getValue();

            for (vertex nNode: nextNode){
                if (nNode.node == null ? nodeName == null : nNode.node.equals(nodeName)) {
                    nNode.setVisitedState(true);
                }
            }

        }
    }

    public List<String> bestFirstSearchtest(String currentLocation, String target){


        if (currentLocation == null ? target != null : !currentLocation.equals(target)){


            traveledList.add(target);
            return traveledList;
        }else{

            if (traveledList.isEmpty()){
                alreadyVisted(currentLocation);
            }

            traveledList.add(currentLocation);
            removeVertex(currentLocation);
            vertex newLocation = smallcheck(currentLocation);

            bestFirstSearch(newLocation.getnode(),target);

        }
        return traveledList;
    }

public List<String> aStarSearch(String currentLocation, String target) {

        if (!traveledList.isEmpty() && !traveledList.contains(target)){
            System.out.println(currentLocation);

            List<vertex> openlist = adjacentVertices.get(currentLocation);

            for (vertex vertexFromopenlist : openlist ){

                vertexFromopenlist.setFinalWeight(vertexFromopenlist.getDistance() + vertexFromopenlist.getHeuristic());
            }

            vertex smallestWeight = openlist.get(0);

            for (vertex vertexFromopenlist : openlist ){

                if (vertexFromopenlist.getFinalWeight()<smallestWeight.getFinalWeight());{
                    smallestWeight = vertexFromopenlist;
                }

            }
             removeVertex(smallestWeight.getNode());
            traveledList.add(smallestWeight.getnode());
            aStarSearch(smallestWeight.getNode(),target);
        }
        return traveledList;
    }

    public List<String> bestFirstSearch(String currentLocation, String target){


        if (currentLocation == null ? target != null : !currentLocation.equals(target)){
            traveledList.add(target);
            return traveledList;
        }

            if (traveledList.isEmpty()){
                alreadyVisted(currentLocation);
            }

            traveledList.add(currentLocation);
            removeVertex(currentLocation);
            vertex newLocation = smallcheck(currentLocation);

        try{
            bestFirstSearch(newLocation.getnode(),target);
        }catch (StackOverflowError stackOverflowError){
            return traveledList;
        }
        return traveledList;
    }


    public vertex smallcheck(String currentLocation){

        ArrayList<vertex> nodeGroup = new ArrayList<>();

        for (vertex vertexCheck: adjacentVertices.get(currentLocation)){
            nodeGroup.add(vertexCheck);
        }

        vertex[] vertexArr = new vertex[nodeGroup.size()];
        for (int i = 0; i< nodeGroup.size();i++){
            vertexArr[i] = nodeGroup.get(i);

        }

        Arrays.sort(vertexArr);

        LinkedHashSet<vertex> set = new LinkedHashSet<>();

        for (int i = 0; i < vertexArr.length; i++) {
            set.add(vertexArr[i]);
        }

        Iterator<vertex> vertexIterator = set.iterator();

        int io = 0;
        vertex smallestDis = null;

        while (vertexIterator.hasNext()){
            if (io == 0){
                smallestDis = vertexIterator.next();
            }else{
                if (vertexIterator.next().getDistance() < smallestDis.getDistance()){
                    smallestDis = vertexIterator.next();
                }
            }
            io++;
        }

        for (int i = 0; i<vertexArr.length; i++) {
            if (!vertexArr[i].isVisted()){
                if (vertexArr[i].getDistance()<smallestDis.getDistance()){
                    smallestDis = vertexArr[i];
                }
            }

        }

        if (smallestDis != null) {
            smallestDis.setVisitedState(true);
        }

        return smallestDis;
    }


    public List<String> greedySearch(String currentLocation, String target){


        if(currentLocation == null ? target != null : !currentLocation.equals(target)){
            traveledList.add(currentLocation);
            String newLocation = randonPicker(currentLocation);

            removeVertex(currentLocation);

            greedySearch(newLocation,target);

        }else{

            traveledList.add(currentLocation);

        }

        return traveledList;
    }

    public String randonPicker(String currentNode){

        List<vertex> node =  adjacentVertices.get(currentNode);

        int size = node.size();
        Random randomIndex= new Random();
        int randomNode = randomIndex.nextInt(size-0) + 0;

        String newLocation = adjacentVertices.get(currentNode).get(randomNode).node;

        return newLocation  ;
    }



    
}
