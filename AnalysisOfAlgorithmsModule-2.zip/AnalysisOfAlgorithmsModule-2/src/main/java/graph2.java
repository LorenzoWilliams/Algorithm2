import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class graph2 {

    private  Map<String, List<vertex>> adjacentVertices;

    public graph2(Map<String, List<vertex>> adjacentVertices) {
        this.adjacentVertices = adjacentVertices;
    }

    public graph2() {
        this.adjacentVertices = new HashMap<>();
    }


    public Map<String, List<vertex>> getAdjacentVertices() {
        return adjacentVertices;
    }

    public void setAdjacentVertices(Map<String, List<vertex>> adjacentVertices) {
        this.adjacentVertices = adjacentVertices;
    }

    

   public void  removeVertex(String node){
        vertex v = new vertex(node);

        adjacentVertices.values().stream().forEach(e -> e.remove(v));

    }



    List<String> closedList = new ArrayList<>();
    public List<String> findRoute(String start, String target) {

        if (closedList.contains(start)){
            System.out.println("already been here");
        }else{
            closedList.add(start);
            System.out.println(start + " Has Been Added");

            List<vertex> currentNode = adjacentVertices.get(start);

            vertex smallest = (vertex) currentNode.toArray()[0];

            System.out.println( smallest.getnode() + " smallest");

            for (int i = 0; i < currentNode.size(); i++) {
                    vertex check = (vertex) currentNode.toArray()[i];
                    System.out.println();
                    if (check.getDistance() < smallest.getDistance()) {
                        System.out.println("Swapping  "+check.getnode() +" For " + smallest.getnode());
                        if (closedList.contains(check)){

                        }else{
                            smallest = check;
                        }
                    }
                }

                if (!(closedList.contains(smallest.getnode()))) {
                    {

                        System.out.println( "before recursive loop :" + smallest.getnode());
                        findRoute(smallest.getnode(),target);
                    }

                }
        }

            return closedList;
        }


    List<String> traveledList = new ArrayList<>();

    public void AStarSearch(String currentLocation, String target){

        if(traveledList.isEmpty()){
            System.out.println("traveled List first element is :" + currentLocation);
            traveledList.add(currentLocation);
            removeVertex(currentLocation);
        }

    }
    int i = 0;
    public List<String> findRouter(String currentLocation, String target){


            if(traveledList.isEmpty()){
                System.out.println("traveled List first element is :" + currentLocation);
                traveledList.add(currentLocation);

            }

            if(traveledList.contains(target)){

                System.out.println("have reached\n\n");

                for (String st:traveledList){
                    System.out.println(st);
                }

                System.out.println("End\n\n");
                return traveledList;

            }

                System.out.println("checkpoint reached");

                for (String st:traveledList){
                    System.out.println(st);
                }

                System.out.println("checkpoint End\n");

                vertex newLocation = smallcheck(currentLocation);

                traveledList.add(newLocation.getnode());
                System.out.println("\n"+newLocation.getnode()+" Has Been Added\n\n");


                    i++;
                findRouter(newLocation.getnode(),target);

                    if(i<5){ }

        return traveledList;
    }

    public vertex smallcheck(String currentLocation){

        vertex smallest = adjacentVertices.get(currentLocation).get(0);

        for (vertex sml: adjacentVertices.get(currentLocation)){
            if (sml.getDistance() < smallest.getDistance()){
                smallest = sml;
            }
        }

        System.out.println("first in list " + smallest.getnode());


        for (vertex listVertex:adjacentVertices.get(currentLocation)) {

            if (traveledList.contains(smallest.getnode())){
                System.out.println("already been here :: " + smallest.node);
                if (!(smallest.getnode().equals(listVertex.getnode()))){
                        smallest = listVertex;
                }
            }
        }
        adjacentVertices.remove(currentLocation);
        return smallest;
    }
}
