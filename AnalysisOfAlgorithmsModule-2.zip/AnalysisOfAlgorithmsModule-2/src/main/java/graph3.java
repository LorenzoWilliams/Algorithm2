import java.lang.reflect.Array;
import java.util.*;

public class graph3 {

    private  Map<vertex, List<vertex>> adjacentVertices;

    public graph3(Map<vertex, List<vertex>> adjacentVertices) {
        this.adjacentVertices = adjacentVertices;
    }

    public graph3() {
        this.adjacentVertices = new HashMap<>();
    }


    public Map<vertex, List<vertex>> getAdjacentVertices() {
        return adjacentVertices;
    }

    public void setAdjacentVertices(Map<vertex, List<vertex>> adjacentVertices) {
        this.adjacentVertices = adjacentVertices;
    }



   public void  removeVertex(String node){
        vertex v = new vertex(node);

        adjacentVertices.values().stream().forEach(e -> e.remove(v));
        adjacentVertices.remove(new vertex(node));

    }





    List<vertex> getAdjacentVertices(String node){
        return adjacentVertices.get(new vertex(node));
    }

    List<String> closedList = new ArrayList<>();
    public List<String> findRoute(String start, String target) {

        if (closedList.contains(start)){
            System.out.println("already been here");
        }else{
            closedList.add(start);
            System.out.println(start + " Has Been Added");

            List<vertex> currentNode = adjacentVertices.get(start);

            vertex smallest = (vertex) currentNode.toArray()[0];

            System.out.println( smallest.getnode() + " smallest");

            for (int i = 0; i < currentNode.size(); i++) {
                    vertex check = (vertex) currentNode.toArray()[i];
                    System.out.println();
                    if (check.getDistance() < smallest.getDistance()) {
                        System.out.println("Swapping  "+check.getnode() +" For " + smallest.getnode());
                        if (closedList.contains(check)){

                        }else{
                            smallest = check;
                        }



                    }

                }

                if (!(closedList.contains(smallest.getnode()))) {
                    {

                        System.out.println( "before recursive loop :" + smallest.getnode());
                        findRoute(smallest.getnode(),target);
                    }

                }
        }
            return closedList;
        }


    List<String> traveledList = new ArrayList<>();

    public void AStarSearch(String currentLocation, String target){

        if(traveledList.isEmpty()){
            System.out.println("traveled List first element is :" + currentLocation);
            traveledList.add(currentLocation);
            removeVertex(currentLocation);
        }

    }
    int i = 0;
    public List<String> findRouter(vertex currentNode,vertex target){


            if(traveledList.isEmpty()){
                System.out.println("traveled List first element is :" + currentNode.getnode());

                traveledList.add(currentNode.getnode());
                currentNode.setVisitedState(true);

            }

                vertex newLocation = smallcheck(currentNode);

                traveledList.add(newLocation.getnode());
                System.out.println("\n"+newLocation.getnode()+" Has Been Added\n\n");


                findRouter(newLocation,target);

        return traveledList;
    }

    public vertex smallcheck(vertex currentLocation){

        ArrayList<vertex> nodeGroup = new ArrayList<>();

        for (vertex vertexCheck: adjacentVertices.get(currentLocation)){
            nodeGroup.add(vertexCheck);
        }

        vertex[] objects = (vertex[]) nodeGroup.toArray();

        Arrays.sort(objects);

        vertex smallestDis = objects[0];

        for (int i = 0; i<objects.length; i++) {
            if (objects[i].isVisted() == false){
                smallestDis = objects[i+1];
                break;
            }

        }

        return smallestDis;

    }

}
