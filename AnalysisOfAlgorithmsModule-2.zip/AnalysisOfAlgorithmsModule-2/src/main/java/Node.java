import java.util.*;

public class Node implements Comparable<Node> {

    private static int idCounter = 0;
    public int id;


    String name;


    public Node parent = null;

    public List<Edge> neighbors;


    public double f = Double.MAX_VALUE;
    public double g = Double.MAX_VALUE;

    public double h;

    Node(double h,String name){
        this.h = h;
        this.id = idCounter++;
        this.neighbors = new ArrayList<>();
        this.name = name;
    }

    @Override
    public int compareTo(Node n) {
        return Double.compare(this.f, n.f);
    }

    public static class Edge {
        Edge(int weight, Node node){
            this.weight = weight;
            this.node = node;
        }

        public int weight;
        public Node node;
    }

    public void addBranch(int weight, Node node){
        Edge newEdge = new Edge(weight, node);
        neighbors.add(newEdge);
    }

    public double calculateHeuristic(Node target){
        return this.h;
    }

    public static void main(String[] args) {
        Node head = new Node(0,"A");
        head.g = 0;

        Node b = new Node(0,"B");
        Node c = new Node(0,"C");

        Node e = new Node(0,"E");
        Node d = new Node(0,"D");

        Node f = new Node(0,"F");
        Node g = new Node(0,"G");
        g.g =0;


        head.addBranch(4, b);
        head.addBranch(3, c);

        b.addBranch(5, f);
        b.addBranch(12, e);

        c.addBranch(7, d);
        c.addBranch(10, e);

        d.addBranch(2,e);

        f.addBranch(16,g);

        e.addBranch(5,g);

        //second connection
        g.addBranch(16,f);
        g.addBranch(5,e);

        f.addBranch(5,b);


        e.addBranch(2,d);
        e.addBranch(10,c);
        e.addBranch(12,b);


        d.addBranch(7,c);

        c.addBranch(3,head);

        b.addBranch(4,head);

        Node r = aStar(g,head );
        printPath(r);

    }

    public static Node aStar(Node start, Node target){
        PriorityQueue<Node> closedList = new PriorityQueue<>();
        PriorityQueue<Node> openList = new PriorityQueue<>();

        start.f = start.g + start.calculateHeuristic(target);
        openList.add(start);

        while(!openList.isEmpty()){
            Node n = openList.peek();
            if(n == target){
                return n;
            }

            for(Edge edge : n.neighbors){
                Node m = edge.node;
                double totalWeight = n.g + edge.weight;

                if(!openList.contains(m) && !closedList.contains(m)){
                    m.parent = n;
                    m.g = totalWeight;
                    m.f = m.g + m.calculateHeuristic(target);
                    openList.add(m);
                } else {
                    if(totalWeight < m.g){
                        m.parent = n;
                        m.g = totalWeight;
                        m.f = m.g + m.calculateHeuristic(target);

                        if(closedList.contains(m)){
                            closedList.remove(m);
                            openList.add(m);
                        }
                    }
                }
            }

            openList.remove(n);
            closedList.add(n);
        }
        return null;
    }

    public static void printPath(Node target){
        Node n = target;

        if(n==null)
            return;

        List<Integer> ids = new ArrayList<>(); 

        List<String > names = new ArrayList<>();

        while(n.parent != null){
            ids.add(n.id);

            names.add(n.name); 

            n = n.parent;
        }
        ids.add(n.id);
        Collections.reverse(ids);

        names.add(n.name);
        Collections.reverse(names);

        for(int id : ids){
            System.out.print(id + " ");
        }
        System.out.println("\n\nNames\n");

        for (String name:names){
            System.out.print("{"+name+"}" + "");
        }
    }

    public static String returnPath(Node target){
        Node n = target;

        if(n==null)
            return null;

        List<Integer> ids = new ArrayList<>(); 

        List<String > names = new ArrayList<>();

        double totalDistance = 0;

        while(n.parent != null){
            ids.add(n.id);

            names.add(n.name); 
             totalDistance =  (totalDistance + n.g);
            n = n.parent;
        }
        ids.add(n.id);
        Collections.reverse(ids);

        names.add(n.name);
        Collections.reverse(names);

        String fullPath = "";
        int index = 0;
        for (String name:names){
            if (index == 0){
                fullPath = name;
            }else{
                fullPath = fullPath + "<------->"+name;
            }
            index++;
        }
        return fullPath + " Total Distance : "+ totalDistance;
    }





    public static String startAStarSearch(String start, String target) {

        Node Lucea = new Node(0,"Lucea");
        Node SantaCruz = new Node(0,"Santa Cruz");
        Node MontegoBay = new Node(0,"Montego Bay");
        Node Falmouth = new Node(0,"Falmouth");
        Node SavannalaMar = new Node(0,"Savanna-la-Mar");
        Node MayPen = new Node(0,"May Pen");
        Node Mandeville = new Node(0,"Mandeville");
        Node SaintAnnsBay = new Node(0,"Saint Ann Bay");
        Node SpanishTown = new Node(0,"Spanish Town");
        Node PortMaria = new Node(0,"Port Maria");
        Node Kingston = new Node(0,"Kingston");
        Node PortAntonio = new Node(0,"Port Antonio");
        Node HalfWayTree = new Node(0,"Half Way Tree");
        Node MorantBay = new Node(0,"Morant Bay");
        Node Negril = new Node(0,"Negril");
        Node Darliston = new Node(0,"Darliston");
        Node Balaclava = new Node(0,"Balaclava");
        Node ClarksTown = new Node(0,"Clark's Town");
        Node BrownsTown = new Node(0,"Brown Town");
        Node Claremont = new Node(0,"Claremont");
        Node Linstead = new Node(0,"Linstead");

        //Node 1
        Negril.addBranch(43,Lucea);
        Negril.addBranch(31,SavannalaMar);
        //Node 2
        Lucea.addBranch(43,Negril);
        Lucea.addBranch(70,Darliston);
        Lucea.addBranch(55,MontegoBay);
        Lucea.addBranch(100, SantaCruz);

        //Node 3
        SavannalaMar.addBranch(31,Negril);
        SavannalaMar.addBranch(53,Darliston);
        SavannalaMar.addBranch(60,SantaCruz);
        //Node 4
        Darliston.addBranch(70,Lucea);
        Darliston.addBranch(53,SavannalaMar);
        Darliston.addBranch(55,Darliston);
        Darliston.addBranch(87,Balaclava);
        Darliston.addBranch(54,MontegoBay);
        //Node 5
        MontegoBay.addBranch(54,Darliston);
        MontegoBay.addBranch(129,Balaclava);
        MontegoBay.addBranch(38,Falmouth);
        MontegoBay.addBranch(55,Lucea);

        //Node 6
        SantaCruz.addBranch(60,SavannalaMar);
        SantaCruz.addBranch(55,Darliston);
        SantaCruz.addBranch(55,Balaclava);
        SantaCruz.addBranch(76,Mandeville);
        SantaCruz.addBranch(100, Lucea);

        //Node 7
        Balaclava.addBranch(129,MontegoBay);
        Balaclava.addBranch(87,Darliston);
        Balaclava.addBranch(55,SantaCruz);
        Balaclava.addBranch(99,ClarksTown);

        // Node 8
        Falmouth.addBranch(38,MontegoBay);
        Falmouth.addBranch(43,ClarksTown);
        Falmouth.addBranch(56,BrownsTown);
        Falmouth.addBranch(57,SaintAnnsBay);

        //Node9
        ClarksTown.addBranch(99,Balaclava);
        ClarksTown.addBranch(111,Mandeville);
        ClarksTown.addBranch(16,BrownsTown);
        ClarksTown.addBranch(43,Falmouth);

        //Node 10
        Mandeville.addBranch(76,SantaCruz);
        Mandeville.addBranch(111,ClarksTown);
        Mandeville.addBranch(53,MayPen);

        //Node 11
        MayPen.addBranch(53,Mandeville);
        MayPen.addBranch(123,BrownsTown);
        MayPen.addBranch(34,SpanishTown);

        //Node 12
        BrownsTown.addBranch(16,ClarksTown);
        BrownsTown.addBranch(123,MayPen);
        BrownsTown.addBranch(46,Claremont);
        BrownsTown.addBranch(56,Falmouth);


        //Node 13
        SaintAnnsBay.addBranch(57,Falmouth);
        SaintAnnsBay.addBranch(27,Claremont);
        SaintAnnsBay.addBranch(75,PortMaria);

        //Node 14
        Claremont.addBranch(27,SaintAnnsBay);
        Claremont.addBranch(46,BrownsTown);
        Claremont.addBranch(35,Linstead);

        //Node 15
        Linstead.addBranch(35,Claremont);
        Linstead.addBranch(30,SpanishTown);
        Linstead.addBranch(49,Kingston);

        //Node 16
        SpanishTown.addBranch(30,Linstead);
        SpanishTown.addBranch(34,MayPen);
        SpanishTown.addBranch(29,Kingston);

        //Node 17
        Kingston.addBranch(29,SpanishTown);
        Kingston.addBranch(49,Linstead);
        Kingston.addBranch(14,HalfWayTree);
        Kingston.addBranch(116,MorantBay);

        //Node 18
        MorantBay.addBranch(116,Kingston);
        MorantBay.addBranch(99,HalfWayTree);
        MorantBay.addBranch(140,PortAntonio);

        //Node 19
        PortAntonio.addBranch(140,MorantBay);
        PortAntonio.addBranch(139,HalfWayTree);
        PortAntonio.addBranch(73,PortMaria);

        //Node 20
        PortMaria.addBranch(73,PortAntonio);
        PortMaria.addBranch(75,SaintAnnsBay);
        PortMaria.addBranch(93,HalfWayTree);

        //Node 21
        HalfWayTree.addBranch(93,PortMaria);
        HalfWayTree.addBranch(139,PortAntonio);
        HalfWayTree.addBranch(99,MorantBay);
        HalfWayTree.addBranch(14,Kingston);


        switch (start){

            case "Lucea" -> Lucea.g =0;
            case "Santa Cruz" -> SantaCruz.g=0;
            case "Montego Bay" -> MontegoBay.g=0;
            case "Falmouth" -> Falmouth.g=0;
            case "Savanna-la-Mar" -> SavannalaMar.g=0;
            case "May Pen" -> MayPen .g=0;
            case "Mandeville" -> Mandeville.g=0;
            case "Saint Ann Bay" -> SaintAnnsBay .g=0;
            case "Spanish Town" -> SpanishTown .g=0;
            case "Port Maria" -> PortMaria .g=0;
            case "Kingston" -> Kingston .g=0;
            case "Port Antonio" -> PortAntonio .g=0;
            case "Half Way Tree" -> HalfWayTree .g=0;
            case "Morant Bay" -> MorantBay .g=0;
            case "Negril" -> Negril.g=0;
            case "Darliston" -> Darliston.g=0;
            case "Balaclava" -> Balaclava  .g=0;
            case "Clark's Town" -> ClarksTown.g=0;
            case "Brown Town" -> BrownsTown  .g=0;
            case "Claremont" -> Claremont .g=0;
            case "Linstead" -> Linstead.g=0;

        }

        Map<String,Node> nodeMap = new HashMap<>();

        nodeMap.put("Lucea",Lucea);
        nodeMap.put("Santa Cruz",SantaCruz);
        nodeMap.put("Montego Bay",MontegoBay);
        nodeMap.put("Falmouth",Falmouth);
        nodeMap.put("Savanna-la-Mar",SavannalaMar );
        nodeMap.put("May Pen",MayPen );
        nodeMap.put("Mandeville",Mandeville);
        nodeMap.put("Saint Ann Bay",SaintAnnsBay );
        nodeMap.put("Spanish Town",SpanishTown );
        nodeMap.put("Port Maria",PortMaria );
        nodeMap.put("Kingston",Kingston );
        nodeMap.put("Port Antonio",PortAntonio );
        nodeMap.put("Half Way Tree",HalfWayTree );
        nodeMap.put("Morant Bay",MorantBay );
        nodeMap.put("Negril",Negril );
        nodeMap.put("Darliston",Darliston   );
        nodeMap.put("Balaclava",Balaclava  );
        nodeMap.put("Clark's Town",ClarksTown  );
        nodeMap.put("Brown Town",BrownsTown  );
        nodeMap.put("Claremont",Claremont );
        nodeMap.put("Linstead",Linstead);

        Node r = aStar(nodeMap.get(start) ,nodeMap.get(target));
       return returnPath(r);
    }
}

