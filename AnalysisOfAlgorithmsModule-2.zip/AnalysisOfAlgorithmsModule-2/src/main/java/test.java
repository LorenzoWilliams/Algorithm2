public  class test {
    public static void main(String[] args) {
        graph4 map = new graph4();



        map.addVertex("A");
        map.addVertex("B");
        map.addVertex("C");
        map.addVertex("D");
        map.addVertex("E");
        map.addVertex("F");

        //A
        map.addEdge("A","B",1,3);
        map.addEdge("A","E",1,10);
        //B
        map.addEdge("B","C",2,4);
        map.addEdge("B","D",1,2);
        //C
        map.addEdge("C","D",5,6);
        map.addEdge("C","E",3,6);
        //D
        map.addEdge("D","E",4,7);
        map.addEdge("D","F",7,3);
        //E
        map.addEdge("E","F",2,8);
        map.addEdge("F","A",8,1);

        System.out.println("Best First Search");
        for (String route: map.bestFirstSearch("A","F")){
            System.out.println("["+route+"]");
        }
        System.out.println("Greedy Search");
       for (String route: map.greedySearch("A","F")){
           System.out.println("["+route+"]");
       }
    }
    
    public static String startGreddySearch(String start,String target){

        graph4 node = new graph4();

        node.addVertex("Lucea");
        node.addVertex("Santa Cruz");
        node.addVertex("Montego Bay");
        node.addVertex("Falmouth");
        node.addVertex("Savanna-la-Mar");
        node.addVertex("May Pen");
        node.addVertex("Mandeville");
        node.addVertex("Saint Ann Bay");
        node.addVertex("Spanish Town");
        node.addVertex("Port Maria");
        node.addVertex("Kingston");
        node.addVertex("Port Antonio");
        node.addVertex("Half Way Tree");
        node.addVertex("Morant Bay");
        node.addVertex("Negril");
        node.addVertex("Darliston");
        node.addVertex("Balaclava");        
        node.addVertex("Clark's Town");
        node.addVertex("Brown Town");
        node.addVertex("Claremont");
        node.addVertex("Linstead");

        //Node 1
        node.addEdge("Negril","Lucea",43);
        node.addEdge("Negril","Savanna-la-Mar",31);

        //Node 2
        node.addEdge("Lucea","Negril",43);
        node.addEdge("Lucea","Darliston",70);
        node.addEdge("Lucea","Montego Bay",55);
        node.addEdge("Lucea", "Santa Cruz", 100);
        
        //Node 3
        node.addEdge("Savanna-la-Mar","Negril",31);
        node.addEdge("Savanna-la-Mar","Darliston",53);
        node.addEdge("Savanna-la-Mar","Santa Cruz",60);
        //Node 4
        node.addEdge("Darliston","Lucea",70);
        node.addEdge("Darliston","Savanna-la-Mar",53);
        node.addEdge("Darliston","Santa Cruz",55);
        node.addEdge("Darliston","Balaclava",87);
        node.addEdge("Darliston","Montego Bay",54);
        //Node 5
        node.addEdge("Montego Bay","Darliston",54);
        node.addEdge("Montego Bay","Balaclava",129);
        node.addEdge("Montego Bay","Falmouth",38);
        node.addEdge("Montego Bay","Lucea",55);
        //Node 6
        node.addEdge("Santa Cruz","Savanna-la-Mar",60);
        node.addEdge("Santa Cruz","Darliston",55);
        node.addEdge("Santa Cruz","Balaclava",55);
        node.addEdge("Santa Cruz","Mandeville",76);
        node.addEdge("Santa Cruz","Lucea",100);
        //Node 7
        node.addEdge("Balaclava","Montego Bay",129);
        node.addEdge("Balaclava","Darliston",87);
        node.addEdge("Balaclava","Santa Cruz",55);
        node.addEdge("Balaclava","Clark's Town",99);
        // Node 8
        node.addEdge("Falmouth","Montego Bay",38);
        node.addEdge("Falmouth","Clark's Town",43);
        node.addEdge("Falmouth","Brown Town",56);
        node.addEdge("Falmouth","Saint Ann Bay",57);
        //Node9
        node.addEdge("Clark's Town","Balaclava",99);
        node.addEdge("Clark's Town","Mandeville",111);
        node.addEdge("Clark's Town","Brown Town",16);
        node.addEdge("Clark's Town","Falmouth",43);
        //Node 10
        node.addEdge("Mandeville","Santa Cruz",76);
        node.addEdge("Mandeville","Clark's Town",111);
        node.addEdge("Mandeville","May Pen",53);
        //Node 11
        node.addEdge("May Pen","Mandeville",53);
        node.addEdge("May Pen","Brown Town",123);
        node.addEdge("May Pen","Spanish Town",34);
        //Node 12
        node.addEdge("Brown Town","Clark's Town",16);
        node.addEdge("Brown Town","May Pen",123);
        node.addEdge("Brown Town","Claremont",46);
        node.addEdge("Brown Town","Falmouth",56);
        //Node 13
        node.addEdge("Saint Ann Bay","Falmouth",57);
        node.addEdge("Saint Ann Bay","Claremont",27);
        node.addEdge("Saint Ann Bay","Port Maria",75);
        //Node 14
        node.addEdge("Claremont","Saint Ann Bay",27);
        node.addEdge("Claremont","Brown Town",46);
        node.addEdge("Claremont","Linstead",35);
        //Node 15
        node.addEdge("Linstead","Claremont",35);
        node.addEdge("Linstead","Spanish Town",30);
        node.addEdge("Linstead","Kingston",49);
        //Node 16
        node.addEdge("Spanish Town","Linstead",30);
        node.addEdge("Spanish Town","May Pen",34);
        node.addEdge("Spanish Town","Kingston",29);
        //Node 17
        node.addEdge("Kingston","Spanish Town",29 );
        node.addEdge("Kingston","Linstead",49 );
        node.addEdge("Kingston","Half Way Tree",14 );
        node.addEdge("Kingston","Morant Bay",116);
        //Node 18
        node.addEdge("Morant Bay","Kingston",116);
        node.addEdge("Morant Bay","Half Way Tree",99);
        node.addEdge("Morant Bay","Port Antonio",140);
        //Node 19
        node.addEdge("Port Antonio","Morant Bay",140);
        node.addEdge("Port Antonio","Half Way Tree",139);
        node.addEdge("Port Antonio","Port Maria",73);
        //Node 20
        node.addEdge("Port Maria","Port Antonio",73);
        node.addEdge("Port Maria","Saint Ann Bay",75);
        node.addEdge("Port Maria","Half Way Tree",93);
        //Node 21
        node.addEdge("Half Way Tree" ,"Port Maria"  ,93 );
        node.addEdge("Half Way Tree" ,"Port Antonio",139);
        node.addEdge("Half Way Tree" ,"Morant Bay"  ,99 );
        node.addEdge("Half Way Tree" ,"Kingston"   ,14 );


        String returningPath = "";
        for (String name:  node.greedySearch(start,target)){
            returningPath = returningPath + " <------> "+ name;
        }
        return returningPath;
    }


    public static String startbestFirstSearch(String start,String target){

        graph4 node = new graph4();

        node.addVertex("Lucea");
        node.addVertex("Santa Cruz");
        node.addVertex("Savanna-la-Mar");
        node.addVertex("Montego Bay");
        node.addVertex("Falmouth");
        node.addVertex("May Pen");
        node.addVertex("Mandeville");
        node.addVertex("Claremont");
        node.addVertex("Saint Ann Bay");
        node.addVertex("Spanish Town");
        node.addVertex("Port Maria");
        node.addVertex("Kingston");
        node.addVertex("Port Antonio");
        node.addVertex("Half Way Tree");
        node.addVertex("Morant Bay");
        node.addVertex("Negril");
        node.addVertex("Darliston");
        node.addVertex("Balaclava");
        node.addVertex("Clark's Town");        
        node.addVertex("Brown Town");
        node.addVertex("Linstead");

        //Node 1
        node.addEdge("Negril","Lucea",43);
        node.addEdge("Negril","Savanna-la-Mar",31);
        //Node 2
        node.addEdge("Lucea","Negril",43);
        node.addEdge("Lucea","Darliston",70);
        node.addEdge("Lucea","Montego Bay",55);
        node.addEdge("Lucea","Santa Cruz",100);
        //Node 3
        node.addEdge("Savanna-la-Mar","Negril",31);
        node.addEdge("Savanna-la-Mar","Darliston",53);
        node.addEdge("Savanna-la-Mar","Santa Cruz",60);
        //Node 4
        node.addEdge("Darliston","Lucea",70);
        node.addEdge("Darliston","Savanna-la-Mar",53);
        node.addEdge("Darliston","Santa Cruz",55);
        node.addEdge("Darliston","Balaclava",87);
        node.addEdge("Darliston","Montego Bay",54);
        //Node 5
        node.addEdge("Montego Bay","Darliston",54);
        node.addEdge("Montego Bay","Balaclava",129);
        node.addEdge("Montego Bay","Falmouth",38);
        node.addEdge("Montego Bay","Lucea",55);
        //Node 6
        node.addEdge("Santa Cruz","Savanna-la-Mar",60);
        node.addEdge("Santa Cruz","Darliston",55);
        node.addEdge("Santa Cruz","Balaclava",55);
        node.addEdge("Santa Cruz","Mandeville",76);
        node.addEdge("Santa Cruz","Lucea",100);
        //Node 7
        node.addEdge("Balaclava","Montego Bay",129);
        node.addEdge("Balaclava","Darliston",87);
        node.addEdge("Balaclava","Santa Cruz",55);
        node.addEdge("Balaclava","Clark's Town",99);
        // Node 8
        node.addEdge("Falmouth","Montego Bay",38);
        node.addEdge("Falmouth","Clark's Town",43);
        node.addEdge("Falmouth","Brown Town",56);
        node.addEdge("Falmouth","Saint Ann Bay",57);
        //Node9
        node.addEdge("Clark's Town","Balaclava",99);
        node.addEdge("Clark's Town","Mandeville",111);
        node.addEdge("Clark's Town","Brown Town",16);
        node.addEdge("Clark's Town","Falmouth",43);
        //Node 10
        node.addEdge("Mandeville","Santa Cruz",76);
        node.addEdge("Mandeville","Clark's Town",111);
        node.addEdge("Mandeville","May Pen",53);
        //Node 11
        node.addEdge("May Pen","Mandeville",53);
        node.addEdge("May Pen","Brown Town",123);
        node.addEdge("May Pen","Spanish Town",34);
        //Node 12
        node.addEdge("Brown Town","Clark's Town",16);
        node.addEdge("Brown Town","May Pen",123);
        node.addEdge("Brown Town","Claremont",46);
        node.addEdge("Brown Town","Falmouth",56);
        //Node 13
        node.addEdge("Saint Ann Bay","Falmouth",57);
        node.addEdge("Saint Ann Bay","Claremont",27);
        node.addEdge("Saint Ann Bay","Port Maria",75);
        //Node 14
        node.addEdge("Claremont","Saint Ann Bay",27);
        node.addEdge("Claremont","Brown Town",46);
        node.addEdge("Claremont","Linstead",35);
        //Node 15
        node.addEdge("Linstead","Claremont",35);
        node.addEdge("Linstead","Spanish Town",30);
        node.addEdge("Linstead","Kingston",49);
        //Node 16
        node.addEdge("Spanish Town","Linstead",30);
        node.addEdge("Spanish Town","May Pen",34);
        node.addEdge("Spanish Town","Kingston",29);
        //Node 17
        node.addEdge("Kingston","Spanish Town",29 );
        node.addEdge("Kingston","Linstead",49 );
        node.addEdge("Kingston","Half Way Tree",14 );
        node.addEdge("Kingston","Morant Bay",116);
        //Node 18
        node.addEdge("Morant Bay","Kingston",116);
        node.addEdge("Morant Bay","Half Way Tree",99);
        node.addEdge("Morant Bay","Port Antonio",140);
        //Node 19
        node.addEdge("Port Antonio","Morant Bay",140);
        node.addEdge("Port Antonio","Half Way Tree",139);
        node.addEdge("Port Antonio","Port Maria",73);
        //Node 20
        node.addEdge("Port Maria","Port Antonio",73);
        node.addEdge("Port Maria","Saint Ann Bay",75);
        node.addEdge("Port Maria","Half Way Tree",93);
        //Node 21
        node.addEdge("Half Way Tree" ,"Port Maria"  ,93 );
        node.addEdge("Half Way Tree" ,"Port Antonio",139);
        node.addEdge("Half Way Tree" ,"Morant Bay"  ,99 );
        node.addEdge("Half Way Tree" ,"Kingston"   ,14 );

        String returningPath = "";
        for (String name:  node.bestFirstSearch(start,target)){
            returningPath = returningPath +"<------>"+ name;
        }
        return returningPath;
    }

    
}